# Gastouderopvang Marianne Website

Modern responsive website voor Gastouderopvang Marianne in Almelo, met geïntegreerde Google Ads conversion tracking en contact formulier.

## Features

- 🎨 **Modern Design** - Responsive layout matching Manus Space original design
- 📞 **Contact Formulier** - Automatische redirect naar bedankpagina
- 📊 **Google Ads Tracking** - Ingebouwde conversion tracking (AW-18030278237)
- 📱 **Mobile Optimized** - Volledig responsive design
- ⚡ **Fast Deployment** - Serverless functions op Vercel

## Structuur

```
├── public/
│   ├── index.html          # Homepage
│   └── bedankpagina.html   # Thank you page
├── api/
│   └── submit-form.js      # Serverless form handler
├── package.json
├── vercel.json            # Vercel configuration
└── README.md
```

## Snel Deployen (1 minuut)

### Via GitHub + Vercel (Aanbevolen)

**Stap 1: Repository op GitHub**

```bash
# 1. Ga naar github.com en log in
# 2. Klik "New" → "New repository"
# 3. Naam: gastouderopvang-marianne
# 4. Selecteer "Public"
# 5. Klik "Create repository"

# Voer deze commands uit in je terminal:
cd /path/to/gastouderopvang-website
git remote add origin https://github.com/YOUR_USERNAME/gastouderopvang-marianne.git
git branch -M main
git push -u origin main
```

**Stap 2: Deploy op Vercel**

1. Ga naar [vercel.com](https://vercel.com)
2. Log in met GitHub (autoriseer Vercel)
3. Klik "New Project"
4. Selecteer `gastouderopvang-marianne` repository
5. Klik "Deploy"
6. Vercel geeft je automatisch een live URL!

**Dat's it!** Je website is nu live en klaar voor Google Ads.

## Website Details

### Contact Informatie
- **Telefoonnummer:** +31 (0)6 30768766
- **Email:** bramwerkhoven@gmail.com
- **Adres:** Tulpenstraat 17, 7601AX Almelo
- **Uren:** Ma-Vr 07:00-18:00

### Google Ads
- **Account ID:** AW-18030278237
- **Conversion Tag:** RZzxCN2X9o0CEN3swJVD
- **Tracking aktief op:** Homepage + bedankpagina + form submit

### Prijzen
- **Uurtarief:** €8,49
- **Max kinderen:** 5
- **Inclusief:** Voeding, luiers, speelgoed, persoonlijke aandacht

## Contact Formulier

Het contact formulier stuurt gegevens naar je Vercel backend en:
1. Tracked een Google Ads conversion
2. Redirectt automatisch naar bedankpagina
3. Kan (optioneel) emails sturen

## Volgende Stappen (Optioneel)

### Email Setup
Wil je contactformulieren via email ontvangen? Voeg dit toe aan `api/submit-form.js`:

```javascript
// Gebruik SendGrid, Mailgun, of ander email service
```

### Custom Domain
1. Koop een domain (bijv: gastouderopvang-marianne.nl)
2. Voeg DNS records toe naar Vercel
3. Connecteer domain in Vercel settings

### Analytics
- Google Ads conversion tracking is al ingebouwd
- Voeg Google Analytics toe voor extra insights

## Support

Vragen? Contacteer Bram op bramwerkhoven@gmail.com

---

Built with ❤️ using HTML, CSS, JavaScript & Vercel
