#!/bin/bash

# 🚀 QUICK DEPLOYMENT SCRIPT - Gastouderopvang Marianne Website
# This script automates the GitHub and Vercel deployment in one command!

echo "╔════════════════════════════════════════════════════════════╗"
echo "║  🚀 Gastouderopvang Marianne - Quick Deploy Script         ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "❌ Git is not installed. Please install Git first."
    exit 1
fi

# Get GitHub username
read -p "👤 GitHub Username (e.g., bramwerkhoven): " GITHUB_USERNAME

if [ -z "$GITHUB_USERNAME" ]; then
    echo "❌ GitHub username is required."
    exit 1
fi

REPO_NAME="gastouderopvang-marianne"
REPO_URL="https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"

echo ""
echo "📋 Deployment Configuration:"
echo "   Repository: $REPO_URL"
echo "   Project: $REPO_NAME"
echo ""

# Configure git if needed
echo "🔧 Configuring Git..."
git config user.email "gastouderopvang@marianne.nl" 2>/dev/null || true
git config user.name "Gastouderopvang Marianne" 2>/dev/null || true

# Add remote
echo "📤 Adding GitHub remote..."
git remote remove origin 2>/dev/null || true
git remote add origin "$REPO_URL"

# Change to main branch
echo "🌿 Switching to main branch..."
git branch -M main 2>/dev/null || true

# Push to GitHub
echo "🚀 Pushing to GitHub (this will prompt for authentication)..."
git push -u origin main

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Successfully pushed to GitHub!"
    echo ""
    echo "════════════════════════════════════════════════════════════"
    echo "📝 NEXT STEPS - Deploy to Vercel:"
    echo "════════════════════════════════════════════════════════════"
    echo ""
    echo "1. Go to: https://vercel.com/new"
    echo "2. Log in with GitHub"
    echo "3. Select: $REPO_NAME"
    echo "4. Click 'Deploy'"
    echo "5. You'll get a live URL in 1 minute!"
    echo ""
    echo "Your website will be live at: https://$REPO_NAME.vercel.app"
    echo ""
else
    echo ""
    echo "❌ Failed to push to GitHub."
    echo ""
    echo "💡 Make sure:"
    echo "   1. You have GitHub account at https://github.com"
    echo "   2. You created repository: https://github.com/$GITHUB_USERNAME/$REPO_NAME"
    echo "   3. You have git credentials configured"
    echo ""
    echo "Manual steps:"
    echo "   git remote add origin $REPO_URL"
    echo "   git branch -M main"
    echo "   git push -u origin main"
    exit 1
fi
