// Serverless function for handling form submissions
// Supports email notification via Vercel KV or Webhook

export default async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { naam, email, telefoon, bericht } = req.body;

    // Validate required fields
    if (!naam || !email || !bericht) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Store submission in logs
    const submission = {
      naam,
      email,
      telefoon,
      bericht,
      timestamp: new Date().toISOString(),
      ip: req.headers['x-forwarded-for'] || req.connection.remoteAddress
    };

    console.log('Form submission:', JSON.stringify(submission, null, 2));

    // OPTIONAL: Send email notification
    // Option 1: Use Vercel Email (if configured)
    // Option 2: Use external service webhook
    // Option 3: Send to your email via serverless function

    // For now, store in environment (you can add email service later)
    if (process.env.NOTIFY_EMAIL) {
      try {
        // Send to your email service
        // Example: await sendEmailNotification(submission);
        console.log('Email notification queued for:', process.env.NOTIFY_EMAIL);
      } catch (emailError) {
        console.error('Email notification failed:', emailError);
        // Don't fail the form submission if email fails
      }
    }

    return res.status(200).json({
      success: true,
      message: 'Form submitted successfully',
      submissionId: Date.now()
    });

  } catch (error) {
    console.error('Form submission error:', error);
    return res.status(500).json({
      error: 'Failed to process form submission'
    });
  }
};
