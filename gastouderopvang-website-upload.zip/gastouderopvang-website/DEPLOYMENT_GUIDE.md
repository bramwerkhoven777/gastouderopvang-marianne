# 🚀 Snelle Deployment Guide

## Optie 1: SNELSTE (5 minuten) - GitHub + Vercel

### Stap 1: Repository op GitHub
1. Ga naar **[github.com/new](https://github.com/new)**
2. Vul in:
   - Repository name: `gastouderopvang-marianne`
   - Description: `Website voor Gastouderopvang Marianne`
   - Select: **Public**
3. Klik **"Create repository"**

### Stap 2: Code naar GitHub pushen
Voer dit in je terminal uit (je mag kopieren-plakken):

```bash
cd /path/to/gastouderopvang-website

git remote add origin https://github.com/YOUR_USERNAME/gastouderopvang-marianne.git
git branch -M main
git push -u origin main
```

(Vervang `YOUR_USERNAME` met jouw GitHub username)

### Stap 3: Deploy op Vercel
1. Ga naar **[vercel.com/new](https://vercel.com/new)**
2. Log in met GitHub
3. Selecteer jouw `gastouderopvang-marianne` repository
4. Klik **"Deploy"**
5. **KLAAR!** Vercel geeft je een live URL

**Je website is nu live!** 🎉

---

## Optie 2: Vercel Template (Nog sneller - 2 minuten)

Klik hier → [Deploy to Vercel](https://vercel.com/new/clone?repository-url=https://github.com/jouw-username/gastouderopvang-marianne)

(Vervang `jouw-username` met je GitHub username na Stap 2)

---

## Website Info

| Item | Waarde |
|------|--------|
| **Live URL** | `gastouderopvang-marianne.vercel.app` (gegeven door Vercel) |
| **Google Ads ID** | AW-18030278237 |
| **Contact Email** | bramwerkhoven@gmail.com |
| **Phone** | +31 (0)6 30768766 |

---

## ✅ Checklist na Deployment

- [ ] Website is online (je hebt een Vercel URL)
- [ ] Homepage laadt correct
- [ ] Contact formulier werkt
- [ ] "Stuur bericht" button redirect naar bedankpagina
- [ ] Google Ads tracking actief

---

## 📧 OPTIONEEL: Email Setup (Contact formulier emails ontvangen)

Momenteel worden formulieren verzonden maar je ontvangt geen email notificatie. Wil je wel emails ontvangen? Hier zijn je opties:

### Optie A: Webhook Service (Eenvoudig)

1. Maak account op [webhook.site](https://webhook.site)
2. Kopieer je unieke URL
3. Update `api/submit-form.js` om naar jouw webhook te sturen
4. Voeg deze regel toe na `console.log()`:

```javascript
if (submission) {
  fetch('YOUR_WEBHOOK_URL', {
    method: 'POST',
    body: JSON.stringify(submission)
  }).catch(err => console.error('Webhook failed:', err));
}
```

### Optie B: Email Service (SendGrid/Mailgun)

1. Maak account op SendGrid.com of Mailgun.com
2. Get API key
3. Update `api/submit-form.js` met email code
4. Set environment variable in Vercel

### Optie C: Eenvoudig: Formulieren via Vercel KV (Premium)

Contact Vercel support voor setup.

---

## 🔗 Custom Domain (Optioneel)

Wil je `gastouderopvang-marianne.nl` in plaats van `*.vercel.app`?

1. Koop domain bij registrar (GoDaddy, Namecheap, etc)
2. In Vercel Settings → Domains
3. Voeg domain toe
4. Update DNS records (Vercel geeft instructies)

---

## 📊 Google Ads Integration

Conversion tracking is al ingebouwd!

**Hoe werkt het:**
1. Bezoekers vullen contact formulier in
2. Form submit trigger Google Ads conversion event
3. Redirect naar bedankpagina (conversion confirmation)
4. Google Ads registreert de conversion

**In Google Ads Dashboard:**
- Ga naar Tools → Conversions
- Zie "Leadformulier indienen" conversions
- Track ROI van je ads

---

## 🆘 Problemen?

### "Repository not found"
- Zorg dat repository `PUBLIC` is
- Check username spelling

### "Permission denied"
- Generate GitHub Personal Access Token
- Use token instead of password

### Website offline
- Check Vercel deployment status
- Review build logs in Vercel dashboard

---

## 📱 Volledig Responsive

Website werkt perfect op:
- ✅ Desktop (1920px+)
- ✅ Tablet (768px-1024px)
- ✅ Mobile (320px-767px)

Test op je telefoon!

---

## 🎨 Customizations

Wil je de website aanpassen? Edit deze bestanden:

- `public/index.html` - Website content & styling
- `public/bedankpagina.html` - Thank you page
- `api/submit-form.js` - Form handling

Dan:
```bash
git add .
git commit -m "Update website"
git push
```

Vercel deployed automatisch!

---

## ✨ Extra Features

- 📊 Built-in Google Ads conversion tracking
- 🔒 HTTPS/SSL (automatic)
- ⚡ Fast (CDN global)
- 📱 Mobile optimized
- 🎯 SEO friendly
- 🚀 Serverless API

---

**Klaar?** Begin bij **Optie 1 Stap 1** hierboven! 🚀
